# SolucionesTema1
Solución del boletín de problemas del tema 1 de Tratamiento de datos para la entrega de la segunda tarea de GitHub que hay que entregar pronto.
Terminado.